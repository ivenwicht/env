#!/bin/bash

echo "||||| installation script |||||"

if [  -f  ~/.bashrc ];then #si le fichier .bashrc existe
	echo "backup du fichier .bashrc..." 
	mv ~/.bashrc ~/.env/backup/.bashrc && echo "reussie" #backup du fichier 
	echo "link....." 
	ln -s ~/.env/files/.bashrc ~/.bashrc && echo "reussie" #copie du fichier bashrc
	
else    #si le fichier .bashrc n existe pas 
        echo "aucune fichier .bashrc"
        echo "Copier le fichier ? o n"
        read -r b #choix de continuer
        if [ $b == "o" ];then #si oui
                echo "lancement de la copie "
                ln -s ~/.env/files/.bashrc ~/.bashrc && echo "reussie" #on copie
        else #si non
        	echo "arret" #arret du script
	fi
fi

echo "||||| fin |||||"
