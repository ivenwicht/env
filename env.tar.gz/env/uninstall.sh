unlink ~/.bashrc 
