#!/bin/bash 
ln -s ~/.env/files/.bashrc ~/.bashrc
